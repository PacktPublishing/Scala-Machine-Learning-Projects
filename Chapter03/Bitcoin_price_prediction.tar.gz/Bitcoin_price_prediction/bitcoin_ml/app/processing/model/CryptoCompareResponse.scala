package processing.model

import play.api.libs.json.Json

/**
  * Created by Denys Kovalenko on 24.10.17.
  * denis.v.kovalenko@gmail.com
  */
/**
  * This is object model of APU
  * @param Response
  * @param Type
  * @param Aggregated
  * @param Data
  * @param FirstValueInArray
  * @param TimeTo
  * @param TimeFrom
  */
case class CryptoCompareResponse(Response : String,
                                Type : Int,
                                Aggregated : Boolean,
                                Data : List[OHLC],
                                FirstValueInArray : Boolean,
                                TimeTo : Long,
                                TimeFrom: Long)

object CryptoCompareResponse {
  implicit val cryptoCompareResponseReads = Json.reads[CryptoCompareResponse]
}
