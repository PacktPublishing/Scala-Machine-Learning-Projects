package processing.model

import play.api.libs.json._

/**
  * Created by Denys Kovalenko on 24.10.17.
  * denis.v.kovalenko@gmail.com
  */

/**
  * This is model class for mapping with CryptoAPI response "data" array internals.
  *
  * @param time - timestamp in seconds, 1508818680 for instance
  * @param open - open price at given minute interval
  * @param high - highest price
  * @param low - lowers price
  * @param close - price at closing of interval
  * @param volumefrom - trading volume in "from" currency. BTC in our case
  * @param volumeto - trading volume in "to" currency. USD in our case.
  *                 Division of volumeto by volumefrom gives us weighted price of BTC
  */
case class OHLC(time: Long,
                open: Double,
                high: Double,
                low: Double,
                close: Double,
                volumefrom: Double,
                volumeto: Double)

object OHLC {
  implicit val implicitOHLCReads = Json.reads[OHLC]
}
