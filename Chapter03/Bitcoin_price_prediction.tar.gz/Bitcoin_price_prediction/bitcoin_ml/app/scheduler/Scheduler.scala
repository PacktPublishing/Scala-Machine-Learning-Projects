package scheduler

import javax.inject.{Inject, Named}

import akka.actor.{ActorRef, ActorSystem}
import play.api.Configuration

import scala.concurrent.ExecutionContext
import scala.concurrent.duration._

/**
  * Created by Denys Kovalenko on 24.10.17.
  * denis.v.kovalenko@gmail.com
  */
class Scheduler @Inject() (val system: ActorSystem, @Named("scheduler-actor") val schedulerActor: ActorRef, configuration: Configuration)(implicit ec: ExecutionContext) {
  //constants.frequency that is set in conf/application.conf file in the bottom
  val frequency = configuration.getInt("constants.frequency").get
  var actor = system.scheduler.schedule(
    0.microseconds, //initial delay - whether execution starts immediately after app launch
    frequency.seconds, //every X seconds, specified above
    schedulerActor,
    "update")

}