package scheduler

import javax.inject._

import akka.actor.{Actor, ActorSystem, Props}
import play.api.{Configuration, Logger}
import play.api.libs.json.JsError
import prediction.PredictionActor
import processing.model.CryptoCompareResponse
import rest.RestClient
import trading.TraderActor
import utils.CryptoCompareDTOToPredictionModelTransformer

import scala.concurrent.ExecutionContext
import scala.util.{Failure, Success}
import scala.concurrent.duration._
import akka.pattern.ask
import akka.util.Timeout
import play.api.db._
import play.api.libs.ws.WSClient
import anorm._
import trading.TraderActor.CurrentDataWithShortTermPrediction

/**
  * Created by Denys Kovalenko on 24.10.17.
  * denis.v.kovalenko@gmail.com
  *
  * * this Actor is main orchestrator - being triggered every 60 seconds,
  * it fetches data from Cryptocompare API about Coinbase  prices,
  * feeds them to Prediction Actor, and re-routes it's response to Trader Actor,
  * that acts based on predictions
  */
@Singleton
class SchedulerActor @Inject()(implicit ec: ExecutionContext,
                               restClient : RestClient,
                               configuration: Configuration,
                               ws: WSClient,
                               db: Database) extends Actor {

  val system = ActorSystem("bitcoin_ml")
  final val predictionActor = system.actorOf(Props(new PredictionActor(configuration, db)))
  final val traderActor = system.actorOf(Props(new TraderActor(ws)))
  final val exchange = "Coinbase"


  /**
    * Dumb method to construct URL for Cryptocompare API.
    * Using hitominute https://www.cryptocompare.com/api/#-api-data-histominute-
    * that allows to get 1-minute data for last 7 days.
    * Currently fetching last 23 minute prices from Coinbase (e parameter - exchange), as we train on 22-minute batches;
    * test previous prediction on 1st 22 records, predict on last 22 records.
    *
    * @return completely formed URL
    */
  def constructUrl(exchange: String): String = {
    "https://min-api.cryptocompare.com/data/histominute?fsym=BTC&tsym=USD&limit=23&aggregate=1&e=" + exchange
  }

  override def receive: Receive = {
    case _ =>
      Logger.info("SchedulerActor job runs at " + System.currentTimeMillis())
      //async call to API with specified parameters
      val futureResponse = restClient.getPayload(constructUrl(exchange))

      futureResponse onComplete {
        //no network failure, etc -> success
        case Success(jsResult) =>  jsResult match  {
          //parsing of JSON has failed
          case jsResult: JsError => Logger.error("error while parsing JSON " + jsResult)
          case jsSuccess =>
            //well-formed result with current price data. to be used for predictions
            val cryptoCompareResponse : CryptoCompareResponse = jsSuccess.get
            Logger.debug("data retrieved:" + cryptoCompareResponse)
            storePriceData(cryptoCompareResponse)

            //sending message with data to prediction Actor
            implicit val timeout: Timeout = 10.seconds
            (predictionActor ? CryptoCompareDTOToPredictionModelTransformer.tranform(cryptoCompareResponse))
              //todo possibly map to mid-range later
              .mapTo[CurrentDataWithShortTermPrediction].map {
              predictedWithCurrent =>
                traderActor ! predictedWithCurrent
            }
        }
        //request has failed
        case Failure(t) => Logger.error("An error has occurred: " + t.getMessage)
      }
  }

  /**
    * This method performs bulk insert of price data into default datasource
    *
    * @param cryptoCompareResponse dto containing price data
    */
  def storePriceData(cryptoCompareResponse: CryptoCompareResponse) = {
    db.withConnection { implicit connection =>
      val transformedPriceDta = cryptoCompareResponse.Data.map(
        ohlc =>
          Seq[NamedParameter](
            "timestamp" -> ohlc.time,
            "exchange" -> exchange,
            "priceOpen" -> ohlc.open,
            "priceClosed" -> ohlc.close,
            "volumeBTC" -> ohlc.volumefrom,
            "volumeUSD" -> ohlc.volumeto)
      )

      /* as some connections to API might fail, we want to have some redundancy;
        thus, every time we get prices from API we insert them into staging db (with perfect connection 22 out of 23 prices were already since previous insert
        After that, we re-insert values that don't exist in main table from staging;
        explanation -> https://www.sqlservercentral.com/Forums/Topic341704-149-1.aspx
        */
      val batch = BatchSql(
        """|INSERT INTO PRICE_STAGING(TIMESTAMP, EXCHANGE, PRICE_OPEN, PRICE_CLOSED, VOLUME_BTC, VOLUME_USD)
          | VALUES({timestamp}, {exchange}, {priceOpen}, {priceClosed}, {volumeBTC}, {volumeUSD})""".stripMargin,
        //clumsy, but Anorm requires this kind of input for batch insert
        transformedPriceDta.head,
        transformedPriceDta.tail: _*
      )
      val res: Array[Int] = batch.execute() // array of update count

      val reInsert = SQL(
        """
          |INSERT INTO PRICE(TIMESTAMP, EXCHANGE, PRICE_OPEN, PRICE_CLOSED, VOLUME_BTC, VOLUME_USD)
          |SELECT  TIMESTAMP, EXCHANGE, PRICE_OPEN, PRICE_CLOSED, VOLUME_BTC, VOLUME_USD
          |FROM PRICE_STAGING AS s
          |WHERE NOT EXISTS (
          |SELECT *
          |FROM PRICE As t
          |WHERE t.TIMESTAMP = s.TIMESTAMP
          |)
        """.stripMargin).execute()
      Logger.debug("reinsert " + reInsert)
    }
  }

}