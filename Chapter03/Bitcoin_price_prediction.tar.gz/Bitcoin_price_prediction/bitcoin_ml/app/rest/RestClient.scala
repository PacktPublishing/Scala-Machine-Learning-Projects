package rest

/**
  * Created by Denys Kovalenko on 24.10.17.
  * denis.v.kovalenko@gmail.com
  */

import javax.inject.Inject

import play.api.libs.json.{JsResult, Json}

import scala.concurrent.Future
import play.api.mvc._
import play.api.libs.ws._
import processing.model.CryptoCompareResponse


class RestClient @Inject() (ws: WSClient)  {

  /**
    * This method fetches correctly formed URL of cryptocompare API https://www.cryptocompare.com/api/#-api-data-histominute-
    *
    * @param url fully-formed URL with all parameters like currency, limit, aggregation specified
    * @return Future that will have response body parsed into data model with price list to be processed on upper level
    */
  def getPayload(url : String): Future[JsResult[CryptoCompareResponse]] = {
    val request: WSRequest = ws.url(url)
    val future = request.get()
    //needed for future
    implicit val context = play.api.libs.concurrent.Execution.Implicits.defaultContext

    future.map {
       response => response.json.validate[CryptoCompareResponse]
    }
  }

}
