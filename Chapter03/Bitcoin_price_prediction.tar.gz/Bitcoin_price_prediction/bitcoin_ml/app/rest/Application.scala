package rest

import javax.inject.Inject

import anorm._
import play.api.db.Database
import play.api.mvc._
import prediction.model.ModelStatistics
import utils.ParserHelper
import views.html.index

class Application @Inject()(db: Database) extends Controller {


  def list = Action { implicit request =>
    db.withConnection { implicit connection =>
      val result = SQL(
        """
          |SELECT  MODEL, SUM(TPR) as TPR, SUM(FPR) as FPR, SUM(TNR) as TNR, SUM(FNR) as FNR, COUNT(*) as TOTAL
          |FROM
          |(SELECT *,
          |case when PREDICTED_LABEL='1' and ACTUAL_PRICE_DELTA > 0 then 1 else 0 end as TPR,
          |case when PREDICTED_LABEL='1' and ACTUAL_PRICE_DELTA <=0 then 1 else 0 end as FPR,
          |case when PREDICTED_LABEL='0' and ACTUAL_PRICE_DELTA <=0 then 1 else 0 end as TNR,
          |case when PREDICTED_LABEL='0' and ACTUAL_PRICE_DELTA >0 then 1 else 0 end as FNR
          |FROM SHORT_TERM_PREDICTION_BINARY)
          |GROUP BY MODEL
        """.stripMargin)
      val rows = result.as(ParserHelper.allRowsParser)
      Ok(index.render(rows))
    }
  }


  //mock up of API to be triggered
  def buy = Action {
    Ok("purchasing")
  }

  def sell = Action {
    Ok("selling")
  }

}