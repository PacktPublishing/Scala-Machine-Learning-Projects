package utils

import java.io.File

import play.api.Logger

/**
  * Created by Denys Kovalenko on 10.11.17.
  * denis.v.kovalenko@gmail.com
  */
object SubDirectoryRetriever {

  /**
    * This method searchs over given directory and returns all sub directories (non-recursive)
    *
    * @param directoryPath directory to search over. Should be rootDir/models
    * @return array, containing tuples of fileName and it's path, for convenience
    */
  def getListOfSubDirectories(directoryPath: String): Array[Map[String, String]] = {
    try {
      new File(directoryPath)
        .listFiles
        .filter(_.isDirectory)
        .map(file => Map("modelName" -> file.getName, "path" -> file.getAbsolutePath))
    } catch {
      case e: NullPointerException => Logger.error("Error occured while fetching list of subdirectories: " + e.getMessage + " ;probably no such directory: " + directoryPath)
        null
    }
  }
}
