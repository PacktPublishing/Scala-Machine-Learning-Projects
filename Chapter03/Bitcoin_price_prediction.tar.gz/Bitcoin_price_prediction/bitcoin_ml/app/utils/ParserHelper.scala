package utils

import anorm._
import prediction.model.ModelStatistics

/**
  * Created by Denys Kovalenko on 11.11.17.
  * denis.v.kovalenko@gmail.com
  */
object ParserHelper {
  val modelStatisticsParser: RowParser[ModelStatistics] = {
    (
      SqlParser.str("MODEL") ~
        SqlParser.int("TPR") ~
        SqlParser.int("FPR") ~
        SqlParser.int("TNR") ~
        SqlParser.int("FNR") ~
        SqlParser.long("TOTAL")
      ) map {
      case name ~ trp ~ fpr ~ tnr ~ fnr ~ total => // etc...
        ModelStatistics(name, trp, fpr, tnr, fnr, total) // etc...
    }
  }

  val allRowsParser = modelStatisticsParser.*


}
