package utils

import prediction.PredictionActor.PriceData
import processing.model.CryptoCompareResponse

/**
  * Created by Denys Kovalenko on 24.10.17.
  * denis.v.kovalenko@gmail.com
  */
object CryptoCompareDTOToPredictionModelTransformer {
  def tranform(dto : CryptoCompareResponse) : PriceData = {
    PriceData(dto.TimeFrom, dto.TimeTo, priceDelta = dto.Data.map(ohlc => (ohlc.time.toLong, ohlc.close - ohlc.open)): _*)
  }
}
