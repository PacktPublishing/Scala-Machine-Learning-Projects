package trading

import javax.inject._

import akka.actor.{Actor, Props}
import akka.actor.Actor.Receive
import play.api.Logger
import play.api.libs.ws.{WSClient, WSRequest}
import prediction.PredictionActor.PriceData
import trading.TraderActor.{CurrentDataWithMidRangePrediction, CurrentDataWithShortTermPrediction}

import scala.concurrent.ExecutionContext
import scala.util.{Failure, Success}

/**
  * Created by Denys Kovalenko on 24.10.17.
  * denis.v.kovalenko@gmail.com
  */
object TraderActor {

  def props = Props[TraderActor]

  case class CurrentDataWithMidRangePrediction(prediction: Double, currentPrice: PriceData)

  //for short term prediction we have classification output -> integer.
  case class CurrentDataWithShortTermPrediction(prediction: String, currentPrice: PriceData)

}

@Singleton
class TraderActor(ws: WSClient) extends Actor {

  implicit val ec = play.api.libs.concurrent.Execution.Implicits.defaultContext

  def notifyBuy(data: CurrentDataWithMidRangePrediction) {
    Logger.info("we should buy -> price will go up to " + data.prediction)
    val request: WSRequest = ws.url("localhost:9000/notify/buy")
    val future = request.get()

    future onComplete {
      case Success(result) =>
        Logger.info("purchased")
      case Failure(t) => Logger.info(t.getMessage)
    }
  }

  def notifyBuyShortTerm() {
    Logger.info("we should buy -> price will go up")
    val request: WSRequest = ws.url("localhost:9000/notify/buy")
    //    val future = request.get()
    //
    //    future onComplete {
    //      case Success(result) =>
    //        Logger.info("purchased")
    //      case Failure(t) => Logger.info(t.getMessage)
    //    }
  }

  def notifySellShortTerm() {
    Logger.info("we should not buy -> price will not increase")
    val request: WSRequest = ws.url("localhost:9000/notify/sell")
    //    val future = request.get()
    //
    //    future onComplete {
    //      case Success(result) =>
    //        Logger.info("sold")
    //      case Failure(t) => Logger.info(t.getMessage)
    //    }
  }

  def notifySell(data: CurrentDataWithMidRangePrediction) {
    Logger.info("we should sell -> price will go down to " + data.prediction)
    val request: WSRequest = ws.url("localhost:9000/notify/sell")
    val future = request.get()

    future onComplete {
      case Success(result) =>
        Logger.info("sold")
      case Failure(t) => Logger.info(t.getMessage)
    }
  }


  /**
    * Here dummy logic of trading is implemented;
    * depending on which message we have received:
    * short-term prediction (int value of class ->price  will rise/fall/stay same)
    * mid-range prediction (double value of predicted price)
    *
    * @return
    */
  override def receive: Receive = {
    case data: CurrentDataWithMidRangePrediction =>
      val lastPrice = data.currentPrice.priceDelta.last._2
      val delta = data.prediction - lastPrice
      /*here is simple logic - if we predict that delta (predicted - current price)
       will be more than 3% of current price (180$ roughly with current BTC price) we send buy signal;
       if BTC will drop for more than 3% we should sell
        */
      if (delta > lastPrice * 0.03) {
        notifyBuy(data)
      } else if (delta < -1 * lastPrice * 0.03) {
        notifySell(data)
      }
    case data: CurrentDataWithShortTermPrediction =>
      Logger.debug("received short-term prediction" + data)
      data.prediction match {
        case "0" => notifySellShortTerm()
        case "1" => notifyBuyShortTerm()
      }
    //todo store into db
    case _ => Logger.error("received not CurrentDataWithPrediction")
  }
}
