package prediction

import javax.inject.Inject

import org.apache.spark.ml.PipelineModel
import org.apache.spark.sql.types._
import org.apache.spark.sql.{DataFrame, Row, SparkSession}
import play.api.{Configuration, Logger}
import prediction.PredictionActor.PriceData

/**
  * Created by Denys Kovalenko on 24.10.17.
  * denis.v.kovalenko@gmail.com
  */


class ShortTermPredictionServiceImpl @Inject()(configuration: Configuration) extends ShortTermPredictionService {

  val spark = SparkSession.builder()
    //todo careful, has to be valid dir on your computer; I have to use this workaround  avoid job failures because of "No space left on device", as it uses /tmp folder. "df -h", which is usually 512mb on Ubuntu
    //    .config("spark.local.‌​dir","/home/denis/tmp")
    .appName("btc_ml")
    //    .config("spark.master", "local")
    .master("local")
    .getOrCreate()


  override def predictPriceDeltaLabel(priceData: PriceData, mlModel: org.apache.spark.ml.Transformer): (String, Row) = {
    val df = transformPriceData(priceData)
    //running classifier
    val prediction = mlModel.transform(df)
    val predictionData = prediction.select("probability", "prediction", "rawPrediction").head()
    Logger.debug("predicting price delta label for time - " + (priceData.timeTo + 60) +
      " Probability distribution: " + predictionData.get(0) +
      " label: " + predictionData.get(1) +
      " rawPrediction: " + predictionData.get(2))
    //returing class label
    (predictionData.get(1).asInstanceOf[Double].toInt.toString, predictionData)
  }

  def transformPriceData(priceData: PriceData): DataFrame = {
    //!! todo hard-coded variable move to conf!!
    val priceList = priceData.priceDelta.toList.map(x => x._2)
    val data = Seq(Row(priceList: _*))
    val xSchema = List(
      StructField("t0", DoubleType, nullable = true),
      StructField("t1", DoubleType, true),
      StructField("t2", DoubleType, true),
      StructField("t3", DoubleType, true),
      StructField("t4", DoubleType, true),
      StructField("t5", DoubleType, true),
      StructField("t6", DoubleType, true),
      StructField("t7", DoubleType, true),
      StructField("t8", DoubleType, true),
      StructField("t9", DoubleType, true),
      StructField("t10", DoubleType, true),
      StructField("t11", DoubleType, true),
      StructField("t12", DoubleType, true),
      StructField("t13", DoubleType, true),
      StructField("t14", DoubleType, true),
      StructField("t15", DoubleType, true),
      StructField("t16", DoubleType, true),
      StructField("t17", DoubleType, true),
      StructField("t18", DoubleType, true),
      StructField("t19", DoubleType, true),
      StructField("t20", DoubleType, true),
      StructField("t21", DoubleType, true)
    )

    spark.createDataFrame(
      spark.sparkContext.parallelize(data),
      StructType(xSchema)
    )
  }

}
