package prediction

import javax.inject._

import akka.actor.{Actor, Props}
import play.api.db.Database
import play.api.{Configuration, Logger}
import prediction.PredictionActor.PriceData
import trading.TraderActor.CurrentDataWithShortTermPrediction
import anorm._
import org.apache.spark.ml.{PipelineModel, Transformer}
import utils.SubDirectoryRetriever

/**
  * Created by Denys Kovalenko on 24.10.17.
  * denis.v.kovalenko@gmail.com
  */
object PredictionActor {
  def props = Props[PredictionActor]

  case class PriceData(timeFrom: Long, timeTo: Long, priceDelta: (Long, Double)*)

}

@Singleton
class PredictionActor(configuration: Configuration, db: Database) extends Actor {
  val rootDir = configuration.getString("rootDir").get
  val productionModelName = configuration.getString("ml.model_version").get
  //folder, in which "*.model" folders with trained models are stored. Convention - rootDir/model
  val modelFolder = rootDir + "models"
  val predictionService = new ShortTermPredictionServiceImpl(configuration)

  /*list of all models stored in rootDir/model.
  All of them will make predictions that will be stored in DB*/
  val models: List[(Transformer, String)] =
  SubDirectoryRetriever
    .getListOfSubDirectories(modelFolder)
    .map(modelMap => (PipelineModel.load(modelMap("path")), modelMap("modelName"))).toList

  val productionModel = PipelineModel.load(rootDir + productionModelName)

  override def receive: Receive = {
    case data: PriceData =>
      /* *********** Disclaimer about prediction **************************
        as this app is as PoC, we need to test classifier as well on the go.
         For that, we retrieve 23 records and make 2 predictions:
         take 1-22 records and predict label of 23th (we know actual answer)
         take 2-23 records and predict currently unknown price

       */
      models.foreach { mlModel =>
        val (predictedLabel, details) = predictionService.predictPriceDeltaLabel(shrinkData(data, 0, 21), mlModel._1)
        val actualDeltaPoint = data.priceDelta.toList(22)
        Logger.info(mlModel._2 + " has predicted " + predictedLabel + " label, actual price delta was " + actualDeltaPoint._2)

        storeShortTermBinaryPredictionIntoDB(
          mlModel._2,
          actualDeltaPoint._1,
          predictedLabel,
          actualDeltaPoint._2)

      }
      val priceData = shrinkData(data, 1, 22)
      val (predictedLabelForUnknownTimestamp, details) = predictionService.predictPriceDeltaLabel(priceData, productionModel)
      Logger.info("Predicting next price change: " + productionModelName + " has predicted " + predictedLabelForUnknownTimestamp + " label for timestamp: " + (priceData.timeTo + 60) +
        "Details: probability distribution: " + details.get(0) +
        " label: " + details.get(1) +
        " rawPrediction: " + details.get(2))

      //calling trading Actor
      sender() ! CurrentDataWithShortTermPrediction(predictedLabelForUnknownTimestamp, data)
    case _ => Logger.error("not instance of CryptoCompareResponse")
  }

  def shrinkData(priceData: PriceData, start: Int, end: Int): PriceData = {
    val list = priceData.priceDelta.toList
    PriceData(list(start)._1, list(end - 1)._1, list.slice(start, end + 1): _*)
  }

  def storeShortTermBinaryPredictionIntoDB(modelVersion: String, timestamp: Long, predictedLabel: String, actualPriceDelta: Double) = {
    db.withConnection { implicit connection =>
      val result = SQL(
        """|INSERT INTO SHORT_TERM_PREDICTION_BINARY(MODEL, TIMESTAMP, PREDICTED_LABEL, ACTUAL_PRICE_DELTA)
          |values ({modelVersion}, {timestamp}, {predictedLabel}, {actualPriceDelta})
        """.stripMargin)
        .on('modelVersion -> modelVersion,
          'timestamp -> timestamp,
          'predictedLabel -> predictedLabel,
          'actualPriceDelta -> actualPriceDelta).executeInsert()
      Logger.debug("insert result = " + result)
      //todo if insert result = false (execution was successful) then clear up staging DB table
    }
  }


}