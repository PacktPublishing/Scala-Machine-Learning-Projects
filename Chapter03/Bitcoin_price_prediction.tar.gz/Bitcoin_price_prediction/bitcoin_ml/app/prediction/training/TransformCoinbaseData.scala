package prediction.training

import org.apache.spark
import org.apache.spark.ml.Pipeline
import org.apache.spark.ml.classification.DecisionTreeClassificationModel
import org.apache.spark.ml.classification.DecisionTreeClassifier
import org.apache.spark.ml.evaluation.MulticlassClassificationEvaluator
import org.apache.spark.ml.feature.{IndexToString, StringIndexer, VectorIndexer}
import org.apache.spark.sql.{Column, DataFrame, SQLContext, SparkSession}

/**
  * Created by Denys Kovalenko on 26  .10.17.
  * denis.v.kovalenko@gmail.com
  */
object TransformCoinbaseData extends App {

  val spark = SparkSession.builder().appName("btc_ml").master("local").getOrCreate()

  val data = spark.read.format("csv").option("header", "true").load("/home/denis/projects/upwork-btc/bitstampUSD_1-min_data_2012-01-01_to_2017-10-20")

  val Array(trainingData, testData) = data.randomSplit(Array(0.7, 0.3))

  val dataWithDelta = data.withColumn("Delta", data("Close") - data("Open"))
//  dataWithDelta.describe("Delta").show()
  //todo filter data since price starts to change, or screw it

  //for when
  import org.apache.spark.sql.functions._
  // for `$`
  import spark.sqlContext.implicits._
  val dataWithLabels = dataWithDelta.withColumn("label", when($"Close" - $"Open" > 0, 1).otherwise(0))
//  dataWithLabels.ta(100)
//  dataWithDelta.
  rollingWindow(dataWithLabels, 3)



  def rollingWindow(data : DataFrame, window : Int) : DataFrame = {
    var i : Long = 0
    val zippedData = data.rdd.zipWithIndex()
    while (i < (data.count()- window)) {
      val x =  zippedData.filter(x => {x._2 >= i && x._2 < i + window}).collect()
      print(x)
      i+=1
    }

    null
  }
}
