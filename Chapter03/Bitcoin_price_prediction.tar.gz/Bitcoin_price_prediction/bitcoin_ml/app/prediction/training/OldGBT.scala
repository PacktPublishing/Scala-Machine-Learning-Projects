package prediction.training

/**
  * Created by Denys Kovalenko on 3.11.17.
  * denis.v.kovalenko@gmail.com
  */
package prediction.training

// $example on$
import org.apache.spark.ml.Pipeline
import org.apache.spark.ml.classification.{GBTClassificationModel, GBTClassifier, RandomForestClassificationModel, RandomForestClassifier}
import org.apache.spark.ml.evaluation.MulticlassClassificationEvaluator
import org.apache.spark.ml.feature.{IndexToString, StringIndexer, VectorAssembler, VectorIndexer}
import org.apache.spark.sql.types.{DoubleType, IntegerType, StructField, StructType}

// $example off$
import org.apache.spark.sql.SparkSession

/**
  * Created by Denys Kovalenko on 27.10.17.
  * denis.v.kovalenko@gmail.com
  */
object TestGBT extends App {
  val rootDir = "/home/denis/projects/upwork-btc/"

  val spark = SparkSession.builder().appName("btc_ml").master("local").getOrCreate()

  val xSchema = StructType(Array(
    StructField("t0", DoubleType, true),
    StructField("t1", DoubleType, true),
    StructField("t2", DoubleType, true),
    StructField("t3", DoubleType, true),
    StructField("t4", DoubleType, true),
    StructField("t5", DoubleType, true),
    StructField("t6", DoubleType, true),
    StructField("t7", DoubleType, true),
    StructField("t8", DoubleType, true),
    StructField("t9", DoubleType, true),
    StructField("t10", DoubleType, true),
    StructField("t11", DoubleType, true),
    StructField("t12", DoubleType, true),
    StructField("t13", DoubleType, true),
    StructField("t14", DoubleType, true),
    StructField("t15", DoubleType, true),
    StructField("t16", DoubleType, true),
    StructField("t17", DoubleType, true),
    StructField("t18", DoubleType, true),
    StructField("t19", DoubleType, true),
    StructField("t20", DoubleType, true),
    StructField("t21", DoubleType, true)
  ))

  val ySchema = StructType(Array(
    StructField("y", DoubleType, true)))


  val x = spark.read.format("csv").schema(xSchema).load(rootDir + "x_CUT612K_22_binary_classes.csv")
  val y_tmp = spark.read.format("csv").schema(ySchema).load(rootDir + "y_CUT612K_22_binary_classes.csv")

  import spark.implicits._

  val y = y_tmp.withColumn("y", 'y.cast(IntegerType))

  // Split the data into training and test sets (30% held out for testing).
  import org.apache.spark.sql.functions._


  val x_id = x.withColumn("id", monotonically_increasing_id())
  val y_id = y.withColumn("id", monotonically_increasing_id())

  val data = x_id.join(y_id, "id")

  // Index labels, adding metadata to the label column.
  // Fit on whole dataset to include all labels in index.
  val labelIndexer = new StringIndexer()
    .setInputCol("y")
    .setOutputCol("indexedLabel")
    .fit(data)

  // Automatically identify categorical features, and index them.
  val featureAssembler = new VectorAssembler()
    .setInputCols(Array("t0", "t1", "t2", "t3", "t4", "t5", "t6", "t7", "t8", "t9", "t10", "t11", "t12", "t13", "t14", "t15", "t16", "t17", "t18", "t19", "t20", "t21"))
    .setOutputCol("features")

  val Array(trainingData, testData) = data.randomSplit(Array(0.7, 0.3))

  //  // Train a RandomForest model.
  //  val rf = new RandomForestClassifier()
  //    .setLabelCol("indexedLabel")
  //    .setFeaturesCol("features")
  //    .setNumTrees(128)

  val gbt = new GBTClassifier()
    .setLabelCol("indexedLabel")
    .setFeaturesCol("features")
    .setMaxIter(30)

  // Convert indexed labels back to original labels.
  val labelConverter = new IndexToString()
    .setInputCol("prediction")
    .setOutputCol("predictedLabel")
    .setLabels(labelIndexer.labels)

  // Chain indexers and forest in a Pipeline.
  //  val pipeline = new Pipeline()
  //    .setStages(Array(labelIndexer,  featureAssembler, rf, labelConverter))
  val pipeline = new Pipeline()
    .setStages(Array(labelIndexer, featureAssembler, gbt, labelConverter))
  // Train model. This also runs the indexers.
  val model = pipeline.fit(trainingData)
  model.save(rootDir + "gbt_22_binary_classes_" + System.nanoTime() / 1000000 + ".model")

  // Make predictions.
  val predictions = model.transform(testData)

  // Select example rows to display.
  predictions.select("predictedLabel", "y", "t0", "t1", "t2", "t3", "t4", "t5", "t6", "t7", "t8", "t9", "t10", "t11", "t12", "t13", "t14", "t15", "t16", "t17", "t18", "t19", "t20", "t21").show(5)

  // Select (prediction, true label) and compute test error.
  val evaluator = new MulticlassClassificationEvaluator()
    .setLabelCol("y")
    .setPredictionCol("prediction")
    .setMetricName("accuracy")
  val accuracy = evaluator.evaluate(predictions)
  println("Test Error = " + (1.0 - accuracy))

  //  val rfModel = model.stages(2).asInstanceOf[RandomForestClassificationModel]
  val gbtModel = model.stages(2).asInstanceOf[GBTClassificationModel]
  println("Learned classification GBT model:\n" + gbtModel.toDebugString)
}
