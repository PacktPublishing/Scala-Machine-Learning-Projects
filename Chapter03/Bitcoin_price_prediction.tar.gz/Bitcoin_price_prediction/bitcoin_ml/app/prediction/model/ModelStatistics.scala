package prediction.model

/**
  * Created by Denys Kovalenko on 11.11.17.
  * denis.v.kovalenko@gmail.com
  */
case class ModelStatistics(name: String, tpr: Int, fpr: Int, tnr: Int, fnr: Int, total: Long)
