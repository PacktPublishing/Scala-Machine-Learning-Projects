//package prediction.model
//
//import javax.inject.Inject
//
//import slick.driver.JdbcProfile
//import slick.lifted.{TableQuery, Tag}
//import slick.model.Table
//
//import scala.concurrent.Future
//
//
//case class Price(id: Long, exchange: String, timestamp: Long, priceOpen: Double, priceClosed: Double, volumeBTC: Double, volumeUSD: Double)
//
//case class ShortTermPrediction(id: Long, model: String, timestamp: Long, predictedLabel: String, actualPriceDelta: Double)
//
//case class MidRangePrediction(id: Long, model: String, timestamp: Long, predictedPrice: Double, actualPrice: Double)
//
//class PredictionRepository @Inject()() {
//
//
//  val prices = TableQuery[PricesTable]
//
//  val shortTermPredictions = TableQuery[ShortTermPredictionTable]
//
//  val midRangePredictions = TableQuery[MidRangePredictionTable]
//
//  class PricesTable(tag: Tag) extends Table[Price](tag, "PRICE") {
//
//    def id = column[Long]("ID", O.AutoInc, O.PrimaryKey)
//
//    def exchange = column[String]("EXCHANGE")
//
//    def timestamp = column[Long]("TIMESTAMP")
//
//    def priceOpen = column[Double]("PRICE_OPEN")
//
//    def priceClosed = column[Double]("PRICE_CLOSED")
//
//    def volumeBTC = column[Double]("VOLUME_BTC")
//
//    def volumeUSD = column[Double]("VOLUME_USD")
//
//    def * = (id, exchange, timestamp, priceOpen, priceClosed, volumeBTC, volumeUSD) <> (Price.tupled, Price.unapply)
//  }
//
//  class ShortTermPredictionTable(tag: Tag) extends Table[ShortTermPrediction](tag, "SHORT_TERM_PREDICTION") {
//
//    def id = column[Long]("ID", O.AutoInc, O.PrimaryKey)
//
//    def model = column[String]("MODEL")
//
//    def timestamp = column[Long]("TIMESTAMP")
//
//    def predictedLabel = column[String]("PREDICTED_LABEL")
//
//    def actualPriceDelta = column[Double]("ACTUAL_PRICE_DELTA")
//
//    def * = (id, model, timestamp, predictedLabel, actualPriceDelta) <> (ShortTermPrediction.tupled, ShortTermPrediction.unapply)
//  }
//
//  class MidRangePredictionTable(tag: Tag) extends Table[MidRangePrediction](tag, "MID_RANGE_PREDICTION") {
//
//    def id = column[Long]("ID", O.AutoInc, O.PrimaryKey)
//
//    def model = column[String]("MODEL")
//
//    def timestamp = column[Long]("TIMESTAMP")
//
//    def predictedPrice = column[Double]("PREDICTED_PRICE")
//
//    def actualPrice = column[Double]("ACTUAL_PRICE")
//
//    def * = (id, model, timestamp, predictedPrice, actualPrice) <> (MidRangePrediction.tupled, MidRangePrediction.unapply)
//  }
//
//}
//
