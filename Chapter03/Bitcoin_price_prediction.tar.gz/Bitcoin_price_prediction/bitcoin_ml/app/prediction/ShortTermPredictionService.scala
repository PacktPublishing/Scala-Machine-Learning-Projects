package prediction

import org.apache.spark.sql.Row
import prediction.PredictionActor.PriceData

/**
  * Created by Denys Kovalenko on 24.10.17.
  * denis.v.kovalenko@gmail.com
  */
trait ShortTermPredictionService {
  def predictPriceDeltaLabel(priceData: PriceData, mlModel: org.apache.spark.ml.Transformer): (String, Row)
}
