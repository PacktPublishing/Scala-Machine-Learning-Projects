package prediction

import prediction.PredictionActor.PriceData

/**
  * Created by Denys Kovalenko on 24.10.17.
  * denis.v.kovalenko@gmail.com
  */
trait PredictionService {
  def predictPrice(priceData: PriceData) : Double
}
